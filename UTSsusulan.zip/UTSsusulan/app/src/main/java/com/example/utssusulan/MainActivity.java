package com.example.utssusulan;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    // VARIABEL UNTUK RECYCLERVIEW (BERITA)
    private RecyclerView rvNews;
    private NewsAdapter newsAdapter;
    private List<NewsItem> newsData;

    // VARIABEL TAMBAHAN UNTUK SLIDER PROMO
    private ViewPager2 vpPromoSlider;
    private PromoSliderAdapter promoAdapter;
    private List<Integer> promoImages;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // --- INISIALISASI SLIDER PROMO (ViewPager2) ---
        vpPromoSlider = findViewById(R.id.vp_promo_slider);

        promoImages = preparePromoData();
        promoAdapter = new PromoSliderAdapter(promoImages);
        vpPromoSlider.setAdapter(promoAdapter);

        // Opsi: Memberi efek peek pada item berikutnya di ViewPager2
        vpPromoSlider.setOffscreenPageLimit(1);
        float pageTranslation = 50f;
        vpPromoSlider.setPageTransformer((page, position) -> {
            page.setTranslationX(position * -pageTranslation);
        });
        // --- END INISIALISASI SLIDER PROMO ---


        // --- INISIALISASI RECYCLERVIEW (Berita) ---
        rvNews = findViewById(R.id.rv_news);
        rvNews.setLayoutManager(new LinearLayoutManager(this));

        newsData = prepareNewsData();

        // Pastikan Anda telah memperbaiki NewsAdapter.java sebelumnya
        newsAdapter = new NewsAdapter(this, newsData);
        rvNews.setAdapter(newsAdapter);
        // --- END INISIALISASI RECYCLERVIEW ---
    }

    /**
     * Metode untuk menyiapkan data gambar promo (untuk ViewPager2)
     */
    private List<Integer> preparePromoData() {
        List<Integer> list = new ArrayList<>();

        // Menggunakan aset yang sudah ada sebagai contoh promo slider
        list.add(R.drawable.ic_promo_banner_placeholder); // Aset utama
        list.add(R.drawable.ic_news_apresiasi_umkm);     // Aset 4 sebagai promo kedua
        list.add(R.drawable.ic_news_video_kompetisi);   // Aset 3 sebagai promo ketiga

        return list;
    }

    /**
     * Metode untuk membuat data berita (untuk RecyclerView)
     */
    private List<NewsItem> prepareNewsData() {
        List<NewsItem> list = new ArrayList<>();

        // 1. ICONNET Meriahkan Electric Colour Run & Expo 2025 di Parepare
        list.add(new NewsItem("ICONNET Meriahkan Electric Colour Run & Expo 2025 di Parepare",
                "Parepare, 26 Sep 2025", 3713, R.drawable.ic_news_run_parepare));

        // 2. ICONNET Hadirkan One Day Service di EV Run 2025 Balikpapan
        list.add(new NewsItem("ICONNET Hadirkan One Day Service di EV Run 2025 Balikpapan",
                "Balikpapan, 14 Sep 2025", 3994, R.drawable.ic_news_ev_run_balikpapan));

        // 3. Kompetisi Video ICONNET Harmoni
        list.add(new NewsItem("Kompetisi Video ICONNET Harmoni",
                "Jakarta, 4 Sep 2025", 2493, R.drawable.ic_news_video_kompetisi));

        // 4. ICONNET Sumbagsel Apresiasi Pelanggan Setia dan Dukung UMKM Lewat Program Traktir Makan Serentak
        list.add(new NewsItem("ICONNET Sumbagsel Apresiasi Pelanggan Setia dan Dukung UMKM Lewat Program Traktir Makan Serentak",
                "Sumatera Selatan, 4 Sep 2025", 4556, R.drawable.ic_news_apresiasi_umkm));

        // 5. ICONNET Dukung Semarak Kemerdekaan di Desa Balongdowo, Candi Sidoarjo
        list.add(new NewsItem("ICONNET Dukung Semarak Kemerdekaan di Desa Balongdowo, Candi Sidoarjo",
                "Sidoarjo, 25 Agu 2025", 3952, R.drawable.ic_promo_banner_placeholder));

        return list;
    }
}