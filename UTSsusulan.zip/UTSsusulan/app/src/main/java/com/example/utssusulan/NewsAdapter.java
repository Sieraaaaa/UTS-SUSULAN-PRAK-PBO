package com.example.utssusulan;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.List;

public class NewsAdapter extends RecyclerView.Adapter<NewsAdapter.NewsViewHolder> {
    private List<NewsItem> newsList;
    private Context context;

    public NewsAdapter(Context context, List<NewsItem> newsList) {
        this.context = context;
        this.newsList = newsList;
    }

    @NonNull
    @Override
    public NewsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate menggunakan R.layout.item_news (pastikan file ini sudah diperbaiki ke AndroidX)
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_news, parent, false);
        return new NewsViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NewsViewHolder holder, int position) {
        NewsItem item = newsList.get(position);

        holder.title.setText(item.getTitle());
        holder.locationDate.setText(item.getLocationDate());
        holder.viewCount.setText(String.valueOf(item.getViewCount()));
        holder.image.setImageResource(item.getImageUrl());
    }

    @Override
    public int getItemCount() {
        return newsList.size();
    }

    public static class NewsViewHolder extends RecyclerView.ViewHolder {
        public TextView title, locationDate, viewCount;
        public ImageView image;

        public NewsViewHolder(View view) {
            super(view);
            // Pastikan ID ini cocok dengan item_news.xml
            title = view.findViewById(R.id.tv_news_title);
            locationDate = view.findViewById(R.id.tv_news_location_date);
            viewCount = view.findViewById(R.id.tv_news_views);
            image = view.findViewById(R.id.iv_news_thumbnail);
        }
    }
}