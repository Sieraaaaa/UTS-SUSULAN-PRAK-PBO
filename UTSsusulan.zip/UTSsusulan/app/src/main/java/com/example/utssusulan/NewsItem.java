package com.example.utssusulan;

public class NewsItem {
    private String title;
    private String locationDate;
    private int viewCount;
    private int imageUrl; // ID resource drawable

    public NewsItem(String title, String locationDate, int viewCount, int imageUrl) {
        this.title = title;
        this.locationDate = locationDate;
        this.viewCount = viewCount;
        this.imageUrl = imageUrl;
    }

    public String getTitle() { return title; }
    public String getLocationDate() { return locationDate; }
    public int getViewCount() { return viewCount; }
    public int getImageUrl() { return imageUrl; }
}
